<?php
/**
 * @package Cristy_Shortcode
 * @version 1.6
 */

/*
Plugin Name: Cristy Shortcode
Plugin URI: 
Description: 
Version: 1.0
Author URI: 
*/